package fr.unicaen.aera128.immobilier.Utils;

import fr.unicaen.aera128.immobilier.Models.Propriete;

public interface OnItemClickListener {
    void onItemClick(Propriete item);
}
